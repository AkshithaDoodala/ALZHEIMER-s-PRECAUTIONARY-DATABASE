import java.util.Random;
import javax.swing.JOptionPane;

public class random {

    public static void main (String[] args) {
        int random_number;
        Random rand = new Random();
        random_number=rand.nextInt(10000);
        JOptionPane.showMessageDialog(null,
            "Value of random number: " + random_number);
    }

}


select p.pname,p.contact_no,p.sym,d.stage from patient p inner join disease d on p.sym=d.sym;